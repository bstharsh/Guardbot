import os
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from dotenv import load_dotenv
from pymongo import MongoClient

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
MONGO_URI = os.getenv("MONGO_URI")
FORCE_JOIN_CHANNEL = os.getenv("FORCE_JOIN_CHANNEL")

client = MongoClient(MONGO_URI)
db = client["modbot"]
users_collection = db["users"]

logging.basicConfig(level=logging.INFO)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not user:
        return

    chat_id = update.effective_chat.id
    member = await context.bot.get_chat_member(FORCE_JOIN_CHANNEL, user.id)

    if member.status in ["left", "kicked"]:
        await context.bot.send_message(chat_id=chat_id, text=f"🚫 Please join {FORCE_JOIN_CHANNEL} to use this bot.")
        return

    await context.bot.send_message(chat_id=chat_id, text="✅ You have access to use the bot!")

if __name__ == "__main__":
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.run_polling()